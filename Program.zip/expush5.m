cla(handles.axes1,'reset')
set(handles.edit29,'String','�����');
global Impcoef1 Impcoef2 ResultM

hh1 = get(handles.edit23,'String');
hh1 = double(str2num(hh1));
kk1 = get(handles.edit24,'String');
kk1 = double(str2num(kk1));
pp1 = get(handles.edit25,'String');
pp1 = double(str2num(pp1));

hh2 = get(handles.edit26,'String');
hh2 = double(str2num(hh2));
kk2 = get(handles.edit27,'String');
kk2 = double(str2num(kk2));
pp2 = get(handles.edit28,'String');
pp2 = double(str2num(pp2));

Impcoef1 = ImpE2(hh1,kk1,pp1,Impcoef1);
Impcoef2 = ImpE2(hh2,kk2,pp2,Impcoef2);

M1=changM(Impcoef1);
M2=changM(Impcoef2);

testsol1=testG(Impcoef1,M1);
testsol2=testG(Impcoef2,M2);

A1=testsol1(1);%x�и� 
B1=testsol1(2);%y�и�
h1=testsol1(3);%�����̵� x��
k1=testsol1(4);%�����̵� y��
p1=testsol1(5);%ȸ���̵� ����

A2=testsol2(1);%x�и�
B2=testsol2(2);%y�и�
h2=testsol2(3);%�����̵� x��
k2=testsol2(4);%�����̵� y��
p2=testsol2(5);%ȸ���̵� ����

[S, Lsol] = flambdaS(M1,M2);
[fignum,Eqsol]=Fdiscriminant2(S,Lsol,Impcoef1,Impcoef2,h1,h2,k1,k2);
[Totalarea,Overlaparea,Polygonarea,OverlapS] = overlapareaF(fignum,Eqsol,A1,B1,h1,k1,p1,A2,B2,h2,k2,p2);
if length(Eqsol(:,1))==4
    Resulteqsol=Eqsol;
end
if length(Eqsol(:,1))==3
    Resulteqsol=[Eqsol;NaN NaN];
end
if length(Eqsol(:,1))==2
    Resulteqsol=[Eqsol;NaN NaN;NaN NaN];
end
if length(Eqsol(:,1))==1
    if isnan(Eqsol)==1
        Resulteqsol=NaN*zeros(4,2);
    else
        Resulteqsol=[Eqsol;NaN NaN;NaN NaN;NaN NaN];
    end
end
ResultM=[Resulteqsol;Totalarea NaN;Overlaparea NaN];
set(handles.uitable2,'data',ResultM);

timeT=linspace(-pi,pi,100);
f11=cos(p1)*(A1*cos(timeT))-sin(p1)*(B1*sin(timeT));
f12=sin(p1)*(A1*cos(timeT))+cos(p1)*(B1*sin(timeT));
pf11=f11+h1;
pf12=f12+k1;

f21=cos(p2)*(A2*cos(timeT))-sin(p2)*(B2*sin(timeT));
f22=sin(p2)*(A2*cos(timeT))+cos(p2)*(B2*sin(timeT));
pf21=f21+h2;
pf22=f22+k2;

axes(handles.axes1);
plot(handles.axes1,pf11,pf12,'b','LineWidth',1.5);hold on
plot(handles.axes1,pf21,pf22,'k','LineWidth',1.5);hold on
if isnan(Eqsol)==0
    plot(handles.axes1,Eqsol(:,1),Eqsol(:,2),'*r');
end
grid on
legend(handles.axes1,'E1','E2','IntP','Location','northeastoutside')
set(handles.edit29,'String','�Ϸ�');