% if s4>0
%     if s2>0
%         if s1>=0 && s3<0
%             %3�� �ȸ���
%             result=pi*(A1*B1+A2*B2);
%             fignum=3;
%         else
%             if s1<0
%                 %3�� �ȸ���
%                 result=pi*(A1*B1+A2*B2);
%                 fignum=3;
%             end
%         end
%     end
% else
%     if s4==0
%         if s2>0 && s3<0
%             %6�� �׸�
%             result=pi*(A1*B1+A2*B2);
%             fignum=6;
%         end
%     end
% end
% 
% %[FF EE CC DD BB AA]
% u2=A41(6);
% u1=A41(5)*y+A41(4);
% u0=A41(3)*y^2+A41(2)*y+A41(1);
% v2=A42(6);
% v1=A42(5)*y+A42(4);
% v0=A42(3)*y^2+A42(2)*y+A42(1);
% Bdeter=simplify((u1*v0-u0*v1)*(u2*v1-u1*v2)-(u2*v0-u0*v2)^2);
% Cofeq4=fliplr(double(coeffs(Bdeter)));
% Eqsol=roots(Cofeq4);
% 
% 
%             
%             
% %             if s3>0
% %                 %4�� �ȸ��� 1,3,4���׸�
% %                 %4�� �ȸ��� 4,5,7,8���׸�
% %             else
% %                 %�ٱ�1�� 6���׸�
% %             end
% %         else
% %             
%                 
% 
% 
% 
% 
% 
% 
% % AA=cos(p)^2/A^2+sin(p)^2/B^2;
% % BB=2*sin(p)*cos(p)*(1/A^2-1/B^2);
% % CC=sin(p)^2/A^2+cos(p)^2/B^2;
% % DD=-2*cos(p)*(h*cos(p)+k*sin(p))/A^2+2*sin(p)*(k*cos(p)-h*sin(p));
% 
% %Another option is to generate a set of points where you will evaluate the function f(x,y) = x^3 + x*y + y^2 and then use the function contour to plot contour lines where f(x,y) is equal to 36:
[x, y] = meshgrid(-3*max(max(A1,B1),max(A2,B2))-max(max(abs(h1),abs(h2)),max(abs(h1),abs(h2))):0.01:3*max(max(A1,B1),max(A2,B2))-max(max(abs(h1),abs(h2)),max(abs(h1),abs(h2))));   % Create a mesh of x and y points
f1 = Impcoef1(1)*x.^2+Impcoef1(2)*x.*y+Impcoef1(3)*y.^2+Impcoef1(4)*x+Impcoef1(5)*y+Impcoef1(6);              % Evaluate f at those points
f2 = Impcoef2(1)*x.^2+Impcoef2(2)*x.*y+Impcoef2(3)*y.^2+Impcoef2(4)*x+Impcoef2(5)*y+Impcoef2(6);               % Evaluate f at those points
contour(x, y, f1, [0 0], 'b');hold on  % Generate the contour plot
contour(x, y, f2, [0 0], 'r');hold on  % Generate the contour plot
xlabel('x');                     % Add an x label
ylabel('y');                     % Add a y label
%title('x^3 + x y + y^2 = 36');   % Add a title
grid on