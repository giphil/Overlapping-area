function F = root2d(x)
Impcoef1=[0.0100000000000000,0,0.111111111111111,0,0,-1];
Impcoef2=[0.111111111111111,0,0.0100000000000000,-0.222222222222222,-0.0200000000000000,-0.878888888888889];
F(1) = Impcoef1(1)*x(1)^2+Impcoef1(2)*x(1)*x(2)+Impcoef1(3)*x(2)^2+Impcoef1(4)*x(1)+Impcoef1(5)*x(2)+Impcoef1(6);              % Evaluate f at those points
F(2) = Impcoef2(1)*x(1)^2+Impcoef2(2)*x(1)*x(2)+Impcoef2(3)*x(2)^2+Impcoef2(4)*x(1)+Impcoef2(5)*x(2)+Impcoef2(6);               % Evaluate f at those points
