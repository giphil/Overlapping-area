function S = segmentArea(A,B,px1,py1,px2,py2,h,k,p)
%UNTITLED3 �� �Լ��� ��� ���� ��ġ
%   �ڼ��� ���� ��ġ
Rp=[cos(-p) -sin(-p);sin(-p) cos(-p)];
RM=Rp*[px1-h px2-h;py1-k py2-k];
x1=RM(1,1);
y1=RM(2,1);
x2=RM(1,2);
y2=RM(2,2);
R = A;
r = B;
xx1 = x1;
xx2 = x2;
if y1 >= 0
    yy1 = sqrt((R)^2-xx1^2);
else
    yy1 = -sqrt((R)^2-xx1^2);
end

if y2 >= 0
    yy2 = sqrt((R)^2-xx2^2);
else
    yy2 = -sqrt((R)^2-xx2^2);
end
if xx1>=0 && yy1>=0
    phi1=atan(yy1/xx1);
elseif xx1<0 && yy1>=0
    phi1=atan(yy1/xx1)+pi;
elseif xx1<0 && yy1<0
    phi1=pi+atan(yy1/xx1);
elseif xx1>=0 && yy1<0
    phi1=atan(yy1/xx1)+2*pi;
end
if xx2>=0 && yy2>=0
    phi2=atan(yy2/xx2);
elseif xx2<0 && yy2>=0
    phi2=atan(yy2/xx2)+pi;
elseif xx2<0 && yy2<0
    phi2=pi+atan(yy2/xx2);
elseif xx2>=0 && yy2<0
    phi2=atan(yy2/xx2)+2*pi;
end
theta = abs(phi1-phi2);
if theta > pi
    theta = 2*pi-theta;
end
S1 = 1/2*(R)^2*theta;
a = sqrt((xx1-xx2)^2+(yy1-yy2)^2);
b = R;
c = R;
s = (a + b + c)/2;
S2 = sqrt(s*(s-a)*(s-b)*(s-c));
S3 = S1-S2;
S = S3*r/R;
end

