clear all
clc
%x^2/A^2+y^2/B^2=1
syms x y real
%AAx^2+BBxy+CCy^2+DDx+EEy+FF=0
% Impcoef=[AA BB CC DD EE FF]
Impcoef1=[9 0 100 0 0 -81];
Impcoef2=[143 0 773 -267 -155 -509];

%[x y 1]M[x y 1]'=0
M1=changM(Impcoef1);
M2=changM(Impcoef2);

testsol1=testG(Impcoef1,M1);
testsol2=testG(Impcoef2,M2);

A1=testsol1(1);%x�и� 
B1=testsol1(2);%y�и�
h1=testsol1(3);%�����̵� x��
k1=testsol1(4);%�����̵� y��
p1=testsol1(5);%ȸ���̵� ����

A2=testsol2(1);%x�и�
B2=testsol2(2);%y�и�
h2=testsol2(3);%�����̵� x��
k2=testsol2(4);%�����̵� y��
p2=testsol2(5);%ȸ���̵� ����

[S, Lsol] = flambdaS(M1,M2);
% %fignum=-1;%��ġ�� �׸� ���� ��ȣ ǥ��
%[fignum,sumreal,Eqsol]=Fdiscriminant(S,Impcoef1,Impcoef2,h1,h2,k1,k2);
[fignum,Eqsol]=Fdiscriminant2(S,Lsol,Impcoef1,Impcoef2,h1,h2,k1,k2);
[Totalarea,Overlaparea,Polygonarea,OverlapS] = overlapareaF(fignum,Eqsol,A1,B1,h1,k1,p1,A2,B2,h2,k2,p2);

timeT=linspace(-pi,pi,100);
f11=cos(p1)*(A1*cos(timeT))-sin(p1)*(B1*sin(timeT));
f12=sin(p1)*(A1*cos(timeT))+cos(p1)*(B1*sin(timeT));
pf11=f11+h1;
pf12=f12+k1;

f21=cos(p2)*(A2*cos(timeT))-sin(p2)*(B2*sin(timeT));
f22=sin(p2)*(A2*cos(timeT))+cos(p2)*(B2*sin(timeT));
pf21=f21+h2;
pf22=f22+k2;

plot(pf11,pf12,'b','LineWidth',1.5);hold on
plot(pf21,pf22,'k','LineWidth',1.5);

%xlim(min(min(pf11),min(pf21)):max(max(pf11),max(pf21)))
% yticks(min(min(pf12),min(pf22)):max(max(pf12),max(pf22)))
if isnan(Eqsol)==0
    plot(Eqsol(:,1),Eqsol(:,2),'*r');
end
legend('E1','E2','IntP')





