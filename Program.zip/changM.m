function M = changM(x)
M=[x(1) x(2)/2 x(4)/2;x(2)/2 x(3) x(5)/2;x(4)/2 x(5)/2 x(6)];