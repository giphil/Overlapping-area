clear all
clc
%x^2/A^2+y^2/B^2=1
A1=5;%x�и�
B1=2;%y�и�
p1=0;%ȸ���̵� ����
h1=0;%�����̵� x��
k1=0;%�����̵� y��


A2=2;%x�и�
B2=5;%y�и�
p2=0;%ȸ���̵� ����
h2=0;%�����̵� x��
k2=0;%�����̵� y��


% syms x y Rx A B h k p Rp RE real
syms x y lambda real
Rp1=[cos(p1) -sin(p1);sin(p1) cos(p1)];
Rp2=[cos(p2) -sin(p2);sin(p2) cos(p2)];
RM1=inv(Rp1)*[x-h1;y-k1];
RM2=inv(Rp2)*[x-h2;y-k2];
RE1=expand(RM1(1)^2/A1^2+RM1(2)^2/B1^2-1);
RE2=expand(RM2(1)^2/A2^2+RM2(2)^2/B2^2-1);

RE1=simplify(RE1);
RE2=simplify(RE2);
%[FF EE CC DD BB AA]
ATT=double(coeffs(RE1,'All'));
A41=[ATT(1,3) ATT(2,2) ATT(3,1) ATT(2,3) ATT(3,2) ATT(3,3)];
% ATT=double(coeffs(RE1,'All'));

% A41=double(coeffs(RE1,'All'));
% A42=double(coeffs(RE2));



PM1=[A41(6) A41(5)/2 A41(4)/2;A41(5)/2 A41(3) A41(2)/2;A41(4)/2 A41(2)/2 A41(1)];
PM2=[A42(6) A42(5)/2 A42(4)/2;A42(5)/2 A42(3) A42(2)/2;A42(4)/2 A42(2)/2 A42(1)];
% 
% fun = @root2d;
% x0 = [0,0,0,0,0];
% xsolve = fsolve(fun,x0);
% 
flambda=coeffs(det(lambda*PM1+PM2));
c=double(flambda(1)/flambda(4));
b=double(flambda(2)/flambda(4));
a=double(flambda(3)/flambda(4));

s1=a;
s2=a^2-3*b;
s3=3*a*c+b*a^2-4*b^2;
s4=-27*c^3+18*c*a*b+a^2*b^2-4*a^3*c-4*b^3;

% fignum=-1;
% if s4>0
%     if s2>0
%         if s1>=0 && s3<0
%             %3�� �ȸ���
%             result=pi*(A1*B1+A2*B2);
%             fignum=3;
%         else
%             if s1<0
%                 %3�� �ȸ���
%                 result=pi*(A1*B1+A2*B2);
%                 fignum=3;
%             end
%         end
%     end
% else
%     if s4==0
%         if s2>0 && s3<0
%             %6�� �׸�
%             result=pi*(A1*B1+A2*B2);
%             fignum=6;
%         end
%     end
% end
% 
% %[FF EE CC DD BB AA]
% u2=A41(6);
% u1=A41(5)*y+A41(4);
% u0=A41(3)*y^2+A41(2)*y+A41(1);
% v2=A42(6);
% v1=A42(5)*y+A42(4);
% v0=A42(3)*y^2+A42(2)*y+A42(1);
% Bdeter=simplify((u1*v0-u0*v1)*(u2*v1-u1*v2)-(u2*v0-u0*v2)^2);
% Cofeq4=fliplr(double(coeffs(Bdeter)));
% Eqsol=roots(Cofeq4);
% 
% 
%             
%             
% %             if s3>0
% %                 %4�� �ȸ��� 1,3,4���׸�
% %                 %4�� �ȸ��� 4,5,7,8���׸�
% %             else
% %                 %�ٱ�1�� 6���׸�
% %             end
% %         else
% %             
%                 
% 
% 
% 
% 
% 
% 
% % AA=cos(p)^2/A^2+sin(p)^2/B^2;
% % BB=2*sin(p)*cos(p)*(1/A^2-1/B^2);
% % CC=sin(p)^2/A^2+cos(p)^2/B^2;
% % DD=-2*cos(p)*(h*cos(p)+k*sin(p))/A^2+2*sin(p)*(k*cos(p)-h*sin(p));
% 
% %Another option is to generate a set of points where you will evaluate the function f(x,y) = x^3 + x*y + y^2 and then use the function contour to plot contour lines where f(x,y) is equal to 36:
% [x, y] = meshgrid(-3*max(max(A1,B1),max(A2,B2))-max(max(abs(h1),abs(h2)),max(abs(h1),abs(h2))):0.01:3*max(max(A1,B1),max(A2,B2))-max(max(abs(h1),abs(h2)),max(abs(h1),abs(h2))));   % Create a mesh of x and y points
% f1 = A41(6)*x.^2+A41(5)*x.*y+A41(4)*x+A41(3)*y.^2+A41(2)*y+A41(1);              % Evaluate f at those points
% f2 = A42(6)*x.^2+A42(5)*x.*y+A42(4)*x+A42(3)*y.^2+A42(2)*y+A42(1);              % Evaluate f at those points
% contour(x, y, f1, [0 0], 'b');hold on  % Generate the contour plot
% contour(x, y, f2, [0 0], 'r');hold on  % Generate the contour plot
% xlabel('x');                     % Add an x label
% ylabel('y');                     % Add a y label
% %title('x^3 + x y + y^2 = 36');   % Add a title
% grid on