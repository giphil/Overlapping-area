function [S, Lsol] = flambdaS(M1,M2)
syms lambda y real
flambda=coeffs(det(lambda*M1+M2),'All');
c=double(flambda(1)/flambda(4));
b=double(flambda(2)/flambda(4));
a=double(flambda(3)/flambda(4));
% f1=lambda^3+a*lambda^2+b*lambda+c;
Dsol=roots([1 a b c]);
LDsol=length(Dsol);
ind=1;
for i=1:LDsol
    if isreal(Dsol(i))==1
        Lsol(ind)=Dsol(i);
        ind=ind+1;
    end
end
s1=a;
s2=a^2-3*b;
s3=3*a*c+b*a^2-4*b^2;
s4=-27*c^3+18*c*a*b+a^2*b^2-4*a^3*c-4*b^3;
S=[s1 s2 s3 s4];

