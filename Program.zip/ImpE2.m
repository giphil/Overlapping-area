function [F,h,k,p] = ImpE2(A,B,h1,k1,p1,h2,k2,p2)
syms x y real
if p1+p2>2*pi
    p=(p1+p2)-2*pi;
else
    p=(p1+p2);
end

Rp1=[cos(p1) -sin(p1);sin(p1) cos(p1)];
Rp2=[cos(p2) -sin(p2);sin(p2) cos(p2)];

pal=[h2;k2]+Rp2*[h1;k1];
h=pal(1);
k=pal(2);

Rp=[cos(p) -sin(p);sin(p) cos(p)];
RM=inv(Rp)*[x-h;y-k];
RE=expand(RM(1)^2/A^2+RM(2)^2/B^2-1);
RE=simplify(RE);
%[FF EE CC DD BB AA]

F1=double(coeffs(RE,'All'));
if h==0 && k~=0
    F=[F1(3,1) F1(2,2) F1(1,3) F1(3,2) F1(2,3) F1(3,3)];
else
    F=[F1(1,3) F1(2,2) F1(3,1) F1(2,3) F1(3,2) F1(3,3)];
end



