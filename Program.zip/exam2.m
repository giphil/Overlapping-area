%         if i==1
%             X1=Lotx;
%             Y1=Loty+1;
%             if mod(Y1,2)==0
%                 Y1=2;
%             else
%                 Y1=mod(Y1,2);
%             end
%             OverlapS(i)=SegA(X1,Y1);
%         else
%             X1=X1+1;
%             Y1=Y1+1;
%             if mod(X1,4)==0
%                 X1=4;
%             else
%                 X1=mod(X1,4);
%             end
%             if mod(Y1,2)==0
%                 Y1=2;
%             else
%                 Y1=mod(Y1,2);
%             end
%             OverlapS(i)=SegA(X1,Y1);
%         end
    end
    Polygonarea=polyarea(Eqsol2(:,1),Eqsol2(:,2));
    Overlaparea=sum(OverlapS)+Polygonarea;
end
if fignum==2
    [max_num, max_idx]=max(SegA(:));
    [Lotx,Loty]=ind2sub(size(SegA),max_idx);
    X1=Lotx;
    Y1=Loty+1;
    X2=Lotx+1;
    Y2=Loty;
    if X2==3
        X2=1;
    end
    if Y1==3
        Y2=1;
    end
    OverlapS(1)=SegA(X1,Y1);
    OverlapS(2)=SegA(X2,Y2);
    Polygonarea=0;
    Overlaparea=sum(OverlapS)+Polygonarea;
end
if fignum==3 || fignum==4
    OverlapS=0;
    Polygonarea=0;
    Overlaparea=sum(OverlapS)+Polygonarea;
end